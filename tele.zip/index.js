
import { startBot } from './events/bot.js';

startBot();