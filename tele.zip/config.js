
export const TELEGRAM_BOT_TOKEN = '8058649447:AAGOAYALpfaPmIenSQm1aS9z-4-_tDpYZgE';

export const REDIRECT_BOT = "None"

export const OWNER_ID = "7879830646"

export const LIMIT = 25;


